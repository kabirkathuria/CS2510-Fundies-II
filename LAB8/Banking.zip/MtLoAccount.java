
// Represents the empty List of Accounts
class MtLoAccount implements ILoAccount {
    
    MtLoAccount() {}
}

