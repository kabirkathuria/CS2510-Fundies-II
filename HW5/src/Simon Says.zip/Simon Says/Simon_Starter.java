import java.awt.Color;
import java.util.Random;

import tester.Tester;
import javalib.funworld.*;
import javalib.worldimages.*;

// Represents a game of Simon Says
class SimonWorld extends World {
  
  ILoButton buttons;
  int brightButton;
  ILoInt sequence;
  ILoInt programmedSequence = new MtLoInt();
  ILoInt userSequence = new MtLoInt();
  Random r = new Random();
  
  int SCENE_SIZE = 400;
  
  Button redButton = new Button(Color.RED, 50, 25, 1, new Posn(100, 100));
  Button yellowButton = new Button(Color.YELLOW, -50, 25, 2, new Posn(150, 100));
  Button blueButton = new Button(Color.BLUE, 50, -75, 3, new Posn(100, 150));
  Button greenButton = new Button(Color.GREEN, -50, -75, 4, new Posn(150, 150));
  
  SimonWorld() {
    this.buttons = 
        new ConsLoButton(redButton, 
            new ConsLoButton(yellowButton, 
                new ConsLoButton(blueButton, 
                    new ConsLoButton(greenButton, 
                        new MtLoButton()))));
    
    this.brightButton = r.nextInt(4) + 1;
    this.sequence = new ConsLoInt(this.brightButton, new MtLoInt());
    this.programmedSequence = this.sequence;
  }
  
  SimonWorld(ILoInt sequence) {
    this();
    this.sequence = sequence;
  }
  
  SimonWorld(ILoInt sequence, int light) {
    this.brightButton = light;
    this.programmedSequence = sequence;
    this.sequence = new MtLoInt();
  }
  
  SimonWorld(int light) {
    this.brightButton = light;
    this.sequence = new MtLoInt();
  }

  // Draw the current state of the world
  public WorldScene makeScene() {
    WorldScene background = new WorldScene(SCENE_SIZE, SCENE_SIZE);
    WorldImage buttonImage = this.buttons.createButtons(this.sequence);
    if (this.brightButton < 0) {
      return this.lastScene("Game over!");
    }
    else {
      return background.placeImageXY(buttonImage, 
          SCENE_SIZE / 2, SCENE_SIZE / 2);
    }
  }

  // handles ticking of the clock and updating the world if needed
  public World onTick() {
    this.sequence = this.sequence.buttonPattern();
    return this;
  }

  // Returns the final scene with the given message displayed
  public WorldScene lastScene(String msg) {
    WorldScene background = new WorldScene(SCENE_SIZE, SCENE_SIZE);
    TextImage text = new TextImage(msg, Color.BLACK);
    return background.placeImageXY(text, 200, 175);
  }

  public SimonWorld onMouseClicked(Posn pos) {
    this.userSequence = new ConsLoInt(this.buttons.clickedButton(pos), this.userSequence);
    if (this.userSequence.length() == this.programmedSequence.length()) {
      if (this.userSequence.sameILoInt(this.programmedSequence)) {
        int bright = r.nextInt(4) + 1;
        return new SimonWorld(new ConsLoInt(bright, this.programmedSequence), bright);
      } else {
        return new SimonWorld();
      }
    }
    else {
      return this;
    }
  }
} 

// Represents a list of buttons
interface ILoButton {
  
  // draws buttons from a list of integers 
  WorldImage createButtons(ILoInt buttons);
  
  // returns if two lists of buttons are the same
  boolean compareButtons(ILoButton other);

  // returns if two non-empty lists are the same
  boolean compareConsLoButton(ConsLoButton other);
  
  // check if this button is on given position 
  int clickedButton(Posn pos);
} 

// Represents an empty list of buttons
class MtLoButton implements ILoButton {

  // create a button
  public WorldImage createButtons(ILoInt buttons) {
    return new EmptyImage();
  }

  // check if a list of buttons includes any empty list of button
  public boolean compareButtons(ILoButton other) {
    return false;
  }

  // check if a list of buttons is same as an empty list of button
  public boolean compareConsLoButton(ConsLoButton other) {
    return false;
  }
  
  // computes the position when user clicks the button 
  public int clickedButton(Posn pos) {
    return 0;
  }
} 

// Represents a non-empty list of buttons
class ConsLoButton implements ILoButton {
  Button first;
  ILoButton rest;

  ConsLoButton(Button first, ILoButton rest) {
    this.first = first;
    this.rest = rest;
  }

  // draws buttons from a non-empty list of buttons
  public WorldImage createButtons(ILoInt buttons) {
    if (buttons.isLit(this.first)) {
      return this.first.drawLit().overlayImages(buttons.createButtonsHelp(this.rest));
    }
    else {
      return this.first.drawDark().overlayImages(this.rest.createButtons(buttons));
    }
  }

  // checks if list of buttons has an empty list of button 
  public boolean compareButtons(ILoButton other) {
    return other.compareConsLoButton(this);
  }

  // checks if this non-empty list of button is same as given non-empty list of buttons 
  public boolean compareConsLoButton(ConsLoButton other) {
    return this.first.equals(other.first) && this.rest.compareButtons(other.rest);
  }
  
  // return to this 
  public int clickedButton(Posn pos) {
    if (this.first.posCheck(pos)) {
      return this.first.num;
    }
    else {
      return this.rest.clickedButton(pos);
    }
  }
} 

// Represents one of the four buttons you can click
class Button {
  Color color;
  int x;
  int y;
  int num;
  Posn pos;

  // Generic constructor
  Button(Color color, int x, int y, int num, Posn pos) {
    this.color = color;
    this.x = x;
    this.y = y;
    this.num = num;
    this.pos = pos;
  }
  
  // Default settings constructor
  Button() {
    this.color = Color.WHITE;
    this.x = 0;
    this.y = 0;
    this.num = 0;
    this.pos = new Posn(0, 0);
  }
  
  // Draw this button dark
  WorldImage drawDark() {
    return this.drawRectangles(this.color.darker().darker()).movePinhole(this.x, this.y);
  }

  // Draw this button lit
  WorldImage drawLit() {
    return this.drawRectangles(this.color.brighter().brighter()).movePinhole(this.x, this.y);
  }

  // compute a new button with a given color
  WorldImage drawRectangles(Color color) {
    return new RectangleImage(100, 100, OutlineMode.SOLID, color); 
  }
  
  //returns if the given number matches this button's number
  boolean compareNums(int inputNum) {
    return this.num == inputNum;
  }

  //check the position of click 
  boolean posCheck(Posn pos) {
    return this.pos.posRange(pos, 15);
  }

  //check if this button and given button are same
  public boolean sameButton(Button that) {
    return this.color == that.color 
        && this.x == that.x 
        && this.y == that.y
        && this.pos == that.pos;
  }
}

// represents a position
class Posn {
  int x;
  int y;

  Posn(int x, int y) {
    this.x = x;
    this.y = y;
  }

  // returns if a position is within a range of given position
  boolean posRange(Posn pos, int distanceRange) {
    int dx = this.x - pos.x;
    int dy = this.y - pos.y;
    return (int) Math.sqrt(dx * dx + dy * dy) <= distanceRange;
  }
}

// represents a list of integers
interface ILoInt {
  
  ILoInt buttonPattern();
  
  // check if a given button is lit in a sequence of integers
  boolean isLit(Button button);

  // reate a buttons with a sequence 
  WorldImage createButtonsHelp(ILoButton buttons);
  
  // check if this list of integers is same as given list of integers
  boolean sameILoInt(ILoInt other);

  // check if this and given non-empty lists of integers are the same
  boolean sameConsLoInt(ConsLoInt other);
  
  // compute the length of a list of integers
  int length();

}

//represents an empty list of integers
class MtLoInt implements ILoInt {
  
  public ILoInt buttonPattern() {
    return this;
  }
  
  // compute if a non-empty list of integers lights a button
  public boolean isLit(Button button) {
    return false;
  }

  // create a buttons with an empty list of integers and sequence 
  public WorldImage createButtonsHelp(ILoButton buttons) {
    return buttons.createButtons(new MtLoInt());
  }  

  // check if an empty list of integer is same as given list of integers
  public boolean sameILoInt(ILoInt that) {
    return false;
  }

  // check if this and given non-empty lists of integers are the same
  public boolean sameConsLoInt(ConsLoInt that) {
    return false;
  }

  // compute the length of an empty list of integers
  public int length() {
    return 0;
  }
}

// represents a non-empty list of integers
class ConsLoInt implements ILoInt {
  int first;
  ILoInt rest;

  ConsLoInt(int f, ILoInt r) {
    this.first = f;
    this.rest = r;
  }

  public ILoInt buttonPattern() {
    return this.rest;
  }

  // compute if a non-empty list of integers lights a button
  public boolean isLit(Button button) {
    return button.compareNums(this.first);
  }

  // create a buttons with a non-empty list of integers and sequence  
  public WorldImage createButtonsHelp(ILoButton buttons) {
    return buttons.createButtons(this.rest);
  }
  
  // check if a non-empty list of integer is same as given list of integers
  public boolean sameILoInt(ILoInt other) {
    return other.sameConsLoInt(this);
  }

  // check if this and given non-empty lists of integers are the same 
  public boolean sameConsLoInt(ConsLoInt other) {
    return this.first == other.first 
        && this.rest.sameILoInt(other.rest);
  }
 
  // compute the length of a non-empty list of integers
  public int length() {
    return this.rest.length() + 1;
  }
}

// Examples
class ExamplesSimon {
  
  // example of new SimonWorld game 
  SimonWorld starterWorld = new SimonWorld();
  int SCENE_SIZE = 400;
  
  //example of a new sequence
  ILoInt exampleSequence = new ConsLoInt(2, new ConsLoInt(1, 
                     new ConsLoInt(3, new MtLoInt())));
 
  // example of new list of button 
  ILoButton exampleButtons = new ConsLoButton(new Button(Color.GREEN, 50, 25, 1, new Posn(150, 150)),
                     new ConsLoButton(new Button(Color.BLUE, -50, 25, 2, new Posn(100, 150)),
                     new ConsLoButton(new Button(Color.YELLOW, 50, -75, 3, new Posn(150, 100)),
                     new ConsLoButton(new Button(Color.RED, -50, -75, 4, new Posn(100, 100)),
                         new MtLoButton()))));
 
  // example of a new MtLoButton
  ILoButton mtButton = new MtLoButton();
 
  // example of a new ConsLoButton
  ILoButton consButtons = new ConsLoButton(new Button(Color.YELLOW, 50, -75, 1, new Posn(150, 150)),
                            mtButton);
 
  // example of new random number generator
  Random r = new Random();
  
  // example of a game with sequence of 1, 2, 3, 4
  SimonWorld simon1 = new SimonWorld(new ConsLoInt(1, new ConsLoInt(2, 
                    new ConsLoInt(3, new ConsLoInt(4, new MtLoInt())))));

  // ILoInt for test 
  ILoInt mt = new MtLoInt();
  ILoInt cons1 = new ConsLoInt(1, (mt));
  ILoInt cons2 = new ConsLoInt(1, new ConsLoInt(2, (mt)));
  ILoInt cons3 = new ConsLoInt(1, (mt));
  
  // Button for test
  Button red = new Button(Color.RED, -50, -75, 4, new Posn(100, 100));

  // Sequence for test 
    ILoInt seq1 = new ConsLoInt(2, new ConsLoInt(4, (mt)));
    ILoInt seq2 = new ConsLoInt(1, new ConsLoInt(3, (mt)));

  // runs the game by creating a world and calling bigBang
  boolean testSimonSays(Tester t) {
    int sceneSize = starterWorld.SCENE_SIZE;
    return starterWorld.bigBang(sceneSize, sceneSize, 1);
  }

  // test the Button 
  boolean testButton(Tester t) {
    return t.checkExpect(starterWorld.brightButton, 4);
  }

  // test for length method
  boolean testLength(Tester t) {
    return t.checkExpect(mt.length(), 0)
            && t.checkExpect(cons1.length(), 1)
            && t.checkExpect(cons2.length(), 2);
  }

  // test for IsLit method 
  boolean testIsLit(Tester t) {
    return t.checkExpect(mt.isLit(red), false)
          && t.checkExpect(cons1.isLit(red), false);
  }

  // test for SameILoInt method
  boolean testSameILoInt(Tester t) {
    return t.checkExpect(mt.sameILoInt(cons1), false)
            && t.checkExpect(cons1.sameILoInt(cons2), false)
            && t.checkExpect(cons1.sameILoInt(cons3), true);
  }

  // test for Button Pattern
  boolean testButtonPattern(Tester t) {
    return t.checkExpect(seq1.buttonPattern(), seq2);
  } 
}


